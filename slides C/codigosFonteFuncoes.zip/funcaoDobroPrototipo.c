#include<stdio.h>

//Protótipo da função
int dobro(int);

int main()
{
    int numero;

    printf("Entre com um número:");
    scanf("%d", &numero);
    printf("O dobro do número é: %d", dobro(numero));
    return 0;
}

int dobro(int numero)
{
    return numero * 2;
}
