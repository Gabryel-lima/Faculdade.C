#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int dobrarNumero(int numero)
{
    return numero * 2;
}

void imprimirLinhaCaracteres(char caractereBorda, int tamanhoLinha)
{
    int colunaTela;

    for (colunaTela = 1; colunaTela <= tamanhoLinha; colunaTela++)
    {
        printf("%c",caractereBorda);
    }
}

void criarInterface(char mensagem[], char caractereBorda)
{
    int tamanhoMensagem = strlen(mensagem);
    int totalCaracteres = tamanhoMensagem * 2;

    printf("\n\n");
    imprimirLinhaCaracteres(caractereBorda, totalCaracteres);
    printf("\n");
    imprimirLinhaCaracteres(caractereBorda, totalCaracteres / 4);
    printf("%s", mensagem);
    imprimirLinhaCaracteres(caractereBorda, totalCaracteres / 4);
    // if (tamanhoMensagem % 2 == 1)
    // {
    //     imprimirLinhaCaracteres(caractereBorda, 1);
    // }
    printf("\n");
    imprimirLinhaCaracteres(caractereBorda, totalCaracteres);
    printf("\n\n");
}

int main()
{
    int numero;
    system("clear");
    criarInterface(" Programa Dobro - Bem Vindo ", '@');
    printf("Entre com um número:");
    scanf("%d", &numero);
    printf("O dobro do número é: %d", dobrarNumero(numero));
    criarInterface(" Programa Dobro - Volte Sempre ", '*');
    return 0;
}
