#include<stdio.h>
#include<stdlib.h>

int main()
{
    int numero;
    system("clear");
    printf("\n\n*********************************");
    printf("\n*********************************");
    printf("\n        Programa Dobro           ");
    printf("\n*********************************");
    printf("\n*********************************\n\n");
    printf("Entre com um número:");
    scanf("%d", &numero);
    printf("O dobro do número é: %d", numero * 2);
    printf("\n\n*********************************");
    printf("\n*********************************");
    printf("\n        Programa Dobro           ");
    printf("\n*********************************");
    printf("\n*********************************\n\n");

    return 0;
}
