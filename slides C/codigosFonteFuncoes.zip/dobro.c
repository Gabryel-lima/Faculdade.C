#include<stdio.h>

int main()
{
    int numero;

    printf("Entre com um número:");
    scanf("%d", &numero);
    printf("O dobro do número é: %d", numero * 2);
    return 0;
}
