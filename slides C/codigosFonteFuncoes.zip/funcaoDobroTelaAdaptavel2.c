#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int dobrarNumero(int numero)
{
    return numero * 2;
}

void criarInterface(char mensagem[], char caractereBorda)
{
    int tamanhoMensagem = strlen(mensagem);
    int totalCaracteres = tamanhoMensagem * 2;
    int colunaTela;

    printf("\n\n");
    for (colunaTela = 1; colunaTela <= totalCaracteres; colunaTela++)
    {
        printf("%c",caractereBorda);
    }
    printf("\n");
    for (colunaTela = 1; colunaTela <= tamanhoMensagem / 2; colunaTela++)
    {
        printf("%c",caractereBorda);
    }
    printf("%s", mensagem);
    for (colunaTela = 1; colunaTela <= tamanhoMensagem / 2; colunaTela++)
    {
        printf("%c",caractereBorda);
    }
    if (tamanhoMensagem % 2 == 1)
    {
        printf("%c",caractereBorda);
    }
    printf("\n");
    for (colunaTela = 1; colunaTela <= totalCaracteres; colunaTela++)
    {
        printf("%c",caractereBorda);
    }
    printf("\n\n");
}

int main()
{
    int numero;
    system("clear");
    criarInterface(" Programa Dobro - Bem Vindo ", '@');
    printf("Entre com um número:");
    scanf("%d", &numero);
    printf("O dobro do número é: %d", dobrarNumero(numero));
    criarInterface(" Programa Dobro - Volte Sempre ", '*');
    return 0;
}
