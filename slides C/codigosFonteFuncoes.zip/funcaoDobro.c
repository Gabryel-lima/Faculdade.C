#include<stdio.h>

int calcularDobro(int numero)
{
    return numero * 2;
}

int main()
{
    int numero;
    printf("Entre com um número:");
    scanf("%d", &numero);
    printf("O dobro do número é: %d", calcularDobro(numero));
    return 0;
}
