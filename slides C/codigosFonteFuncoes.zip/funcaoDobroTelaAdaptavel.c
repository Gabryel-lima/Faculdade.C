#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int dobrarNumero(int numero)
{
    return numero * 2;
}

void criarInterface(char mensagem[], char caractereBorda)
{
    int tamanhoMensagem = strlen(mensagem);
    int totalCaracteres = tamanhoMensagem * 2;
    int colunaTela;

    printf("\n\n");
    for (colunaTela = 1; colunaTela <= totalCaracteres; colunaTela++)
    {
        printf("%c",caractereBorda);
    }
    printf("\n");
    for (colunaTela = 1; colunaTela <= tamanhoMensagem / 2; colunaTela++)
    {
        printf(" ");
    }
    printf("%s", mensagem);
    printf("\n");
    for (colunaTela = 1; colunaTela <= totalCaracteres; colunaTela++)
    {
        printf("%c",caractereBorda);
    }
    printf("\n\n");
}

int main()
{
    int numero;
    char mensagem[50];

    system("clear");
    strcpy(mensagem, "Programa Dobro -  Início");
    criarInterface(mensagem, '@');
    printf("Entre com um número:");
    scanf("%d", &numero);
    printf("O dobro do número é: %d", dobrarNumero(numero));
    strcpy(mensagem, "Programa Dobro - Fim");
    criarInterface(mensagem, '#');
    strcpy(mensagem, "Obrigado por usar o programa");
    criarInterface(mensagem, '*');
    return 0;
}
