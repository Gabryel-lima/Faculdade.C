#include<stdio.h>
#include<stdlib.h>

void apresentarMensagem()
{
    printf("\n\n*********************************");
    printf("\n*********************************");
    printf("\n        Programa Dobro           ");
    printf("\n*********************************");
    printf("\n*********************************\n\n");
}

int main()
{
    int numero;
    system("clear");
    apresentarMensagem();
    printf("Entre com um número:");
    scanf("%d", &numero);
    printf("O dobro do número é: %d", numero * 2);
    apresentarMensagem();
    return 0;
}
